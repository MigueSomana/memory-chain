<?php
/**
 * Plugin Name: Algol+ Condición: Regla Suprema
 * Description: Condición personalizada de carrito que se aplica solo una vez por usuario, visible como "Regla Suprema".
 * Version: 1.0
 * Author: TuNombre
 */

if ( ! defined( 'ABSPATH' ) ) exit;

require_once plugin_dir_path(__FILE__) . 'class-condition-regla-suprema.php';
