<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<label>
  Regla Suprema – Etiqueta única:
  <input type="text" name="value" value="<?php echo esc_attr( $value ?? '' ); ?>"
         placeholder="Ej: promo_unica_2025" />
</label>
