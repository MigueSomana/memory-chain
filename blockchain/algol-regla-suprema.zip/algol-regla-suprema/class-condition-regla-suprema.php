<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class WDP_Custom_Condition_Regla_Suprema {

    public function __construct() {
        add_filter('wdp_conditions', [ $this, 'register_condition' ]);
        add_filter('wdp_is_apply_rule', [ $this, 'maybe_apply_rule'], 10, 3);
    }

    public function register_condition( $conditions ) {
        $conditions[ 'regla_suprema' ] = array(
            'name'     => 'regla_suprema',
            'title'    => 'Regla Suprema',
            'group'    => 'cart', // asegura que aparezca en Condiciones de Carrito
            'template' => plugin_dir_path(__FILE__) . 'custom-template-regla-suprema.php',
            'callback' => [ $this, 'check_condition' ],
        );
        return $conditions;
    }

    public function maybe_apply_rule( $apply, $rule, $context ) {
        if ( empty($rule->condition) || $rule->condition !== 'regla_suprema' ) {
            return $apply;
        }
        // $rule->value es la etiqueta de control
        return $this->check_condition($rule->value ?? '', $context['cart'], [], $context);
    }

    public function check_condition( $value, $cart, $options, $context ) {
        if ( ! is_user_logged_in() || empty($value) ) {
            return false;
        }

        $user_id  = get_current_user_id();
        $tag      = sanitize_key($value);
        $meta_key = '_regla_suprema_' . $tag;

        if ( get_user_meta($user_id, $meta_key, true) ) {
            return false;
        }

        update_user_meta($user_id, $meta_key, 1);
        return true;
    }
}

new WDP_Custom_Condition_Regla_Suprema();
