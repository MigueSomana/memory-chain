<?php
/**
 * Plugin Name: Límite de Producto por Usuario - Avanzado
 * Description: Evita que un usuario adquiera más de 1 unidad de un producto, incluso si es agregado automáticamente al carrito.
 * Version: 1.1
 * Author: Tu Nombre
 */

define('PRODUCTO_LIMITADO_ID', 18101); // Cambia 123 por el ID real del producto a limitar

add_action('woocommerce_before_checkout_form', 'verificar_limite_producto_carrito');
add_action('woocommerce_before_cart', 'verificar_limite_producto_carrito');

function verificar_limite_producto_carrito() {
    if (!is_user_logged_in()) {
        return;
    }

    $user_id = get_current_user_id();
    $product_id = PRODUCTO_LIMITADO_ID;

    // Verifica si ya compró el producto antes
    $args = array(
        'customer_id' => $user_id,
        'limit'       => -1,
        'status'      => array('wc-completed', 'wc-processing'),
    );

    $orders = wc_get_orders($args);
    $total_comprado = 0;

    foreach ($orders as $order) {
        foreach ($order->get_items() as $item) {
            if ((int)$item->get_product_id() === $product_id) {
                $total_comprado += $item->get_quantity();
            }
        }
    }

    // Verifica el carrito actual
    foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
        if ((int)$cart_item['product_id'] === $product_id) {
            $total_comprado += $cart_item['quantity'];

            if ($total_comprado > 1) {
                WC()->cart->remove_cart_item($cart_item_key);
                wc_add_notice(__('Ya has comprado este producto. No puedes adquirir más de una unidad.'), 'error');
            }
        }
    }
}

